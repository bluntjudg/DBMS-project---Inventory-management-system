<?php
include 'db.php'; // Include database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    // Insert supplier into the database
    $sql = "INSERT INTO suppliers (name, email, phone) VALUES ('$name', '$email', '$phone')";
    if ($conn->query($sql) === TRUE) {
        echo "<script>
            alert('Supplier added successfully!');
            window.location.href = 'suppliers.php'; // Redirect to suppliers page
        </script>";
    } else {
        echo "<script>
            alert('Error adding supplier: " . $conn->error . "');
        </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Supplier</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            padding: 20px;
        }
        .container {
            max-width: 500px;
            margin: auto;
            background: #fff;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            font-size: 14px;
            margin-bottom: 5px;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .btn {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #45a049;
        }
        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            text-decoration: none;
            color: #555;
        }
        .back-link:hover {
            color: #4CAF50;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Add Supplier</h1>
        <form method="POST" action="">
            <div class="form-group">
                <label for="name">Supplier Name:</label>
                <input type="text" id="name" name="name" placeholder="Enter supplier name" required>
            </div>
            <div class="form-group">
                <label for="email">Supplier Email:</label>
                <input type="email" id="email" name="email" placeholder="Enter supplier email" required>
            </div>
            <div class="form-group">
                <label for="phone">Supplier Phone:</label>
                <input type="text" id="phone" name="phone" placeholder="Enter supplier phone number" required>
            </div>
            <button type="submit" class="btn">Add Supplier</button>
        </form>
        <a href="suppliers.php" class="back-link">Back to Suppliers</a>
    </div>
</body>
</html>
