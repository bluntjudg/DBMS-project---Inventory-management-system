<?php
$host = 'localhost';
$db = 'inventory_db';
$user = 'root'; // Default user for XAMPP/WAMP
$password = ''; // Default password is empty for XAMPP/WAMP

// Create connection
$conn = new mysqli($host, $user, $password, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
