<?php
session_start();
include 'db.php'; // Include the database connection

// Redirect to login if the user is not logged in
if (!isset($_SESSION['user_name'])) {
    header("Location: index.php");
    exit();
}

// Handle form submission to add a new product
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['addProduct'])) {
    $productName = $_POST['productName'];
    $productPrice = $_POST['productPrice'];
    $productStock = $_POST['productStock'];

    $sql = "INSERT INTO products (name, price, stock) VALUES ('$productName', '$productPrice', '$productStock')";
    if ($conn->query($sql) === TRUE) {
        $message = "Product added successfully!";
    } else {
        $message = "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - Inventory Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }
        .navbar {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            text-align: right;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            margin-left: 20px;
        }
        .container {
            padding: 20px;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .header h1 {
            color: #333;
        }
        .add-btn {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .add-btn:hover {
            background-color: #45a049;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        table th {
            background-color: #4CAF50;
            color: white;
        }
        table tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        table tr:hover {
            background-color: #ddd;
        }
        .form-popup {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: white;
            padding: 20px;
            border: 1px solid #ccc;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            z-index: 1000;
            border-radius: 8px;
        }
        .form-popup input, .form-popup button {
            width: 100%;
            margin: 10px 0;
            padding: 10px;
        }
        .form-popup .close-btn {
            background-color: #f44336;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="welcome.php">Dashboard</a>
        <a href="logout.php">Logout</a>
    </div>

    <div class="container">
        <div class="header">
            <h1>Products</h1>
            <button class="add-btn" onclick="openForm()">Add Product</button>
        </div>

        <!-- Product List -->
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Stock</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Fetch products from the database
                $sql = "SELECT * FROM products";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['name'] . "</td>";
                        echo "<td>" . $row['price'] . "</td>";
                        echo "<td>" . $row['stock'] . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>No products found</td></tr>";
                }
                ?>
            </tbody>
        </table>

        <!-- Add Product Form -->
        <div class="form-popup" id="addProductForm">
            <form method="POST" action="">
                <h2>Add Product</h2>
                <input type="text" name="productName" placeholder="Product Name" required>
                <input type="number" name="productPrice" placeholder="Product Price" required>
                <input type="number" name="productStock" placeholder="Product Stock" required>
                <button type="submit" name="addProduct">Add Product</button>
                <button type="button" class="close-btn" onclick="closeForm()">Cancel</button>
            </form>
        </div>

        <?php if (isset($message)) echo "<p>$message</p>"; ?>
    </div>

    <script>
        function openForm() {
            document.getElementById("addProductForm").style.display = "block";
        }
        function closeForm() {
            document.getElementById("addProductForm").style.display = "none";
        }
    </script>
</body>
</html>
