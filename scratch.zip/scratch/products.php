<?php
// Include the database connection file
include('db.php');  // Make sure to include your actual database connection here

// Fetch stock levels from the inventory table
$inventorySql = "SELECT * FROM inventory WHERE stock_level < 5";
$inventoryResult = $conn->query($inventorySql);

// Check if stock is less than 5 and insert a warning into stock_warnings table
if ($inventoryResult->num_rows > 0) {
    while ($row = $inventoryResult->fetch_assoc()) {
        // Check if a warning already exists for this product
        $checkWarningSql = "SELECT * FROM stock_warnings WHERE product_id = " . $row['product_id'];
        $checkWarningResult = $conn->query($checkWarningSql);

        if ($checkWarningResult->num_rows == 0) { // No warning exists yet
            $warningMessage = "Stock level for product ID " . $row['product_id'] . " is below 5.";
            $insertWarningSql = "INSERT INTO stock_warnings (product_id, warning_message, warning_date) 
                                 VALUES (" . $row['product_id'] . ", '" . $conn->real_escape_string($warningMessage) . "', NOW())";
            $conn->query($insertWarningSql);
        }
    }
}

// Fetch warnings from stock_warnings table
$warningsSql = "SELECT * FROM stock_warnings ORDER BY warning_date DESC";
$warningsResult = $conn->query($warningsSql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
    <style>
        /* Add custom styles for the warning */
        .warning {
            background-color: #f8d7da;
            color: #721c24;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #f5c6cb;
            border-radius: 4px;
        }

        /* Table styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        /* Button styling */
        .button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            cursor: pointer;
            text-decoration: none;
            border-radius: 4px;
        }

        .button:hover {
            background-color: #45a049;
        }

        /* Delete Button styling */
        .delete-button {
            background-color: #f44336;
        }

        .delete-button:hover {
            background-color: #e53935;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Products</h1>

        <!-- Display stock warnings -->
        <?php
        if ($warningsResult->num_rows > 0) {
            while ($warning = $warningsResult->fetch_assoc()) {
                echo "<div class='warning'>";
                echo "<strong>Stock Warning:</strong> " . htmlspecialchars($warning['warning_message']);
                echo "</div>";
            }
        } else {
            echo "<div>No stock warnings.</div>";
        }
        ?>

        <!-- Product Table (Display Products Here) -->
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Stock Level</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Fetching products and their stock levels by joining products and inventory tables
                $productsSql = "
                    SELECT products.id, products.name, products.price, inventory.stock_level 
                    FROM products
                    JOIN inventory ON products.id = inventory.product_id
                ";
                $productsResult = $conn->query($productsSql);
                if ($productsResult->num_rows > 0) {
                    while ($row = $productsResult->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['name'] . "</td>";
                        echo "<td>" . $row['price'] . "</td>";
                        echo "<td>" . $row['stock_level'] . "</td>";
                        echo "<td>
                            <a href='edit_product.php?id=" . $row['id'] . "' class='button'>Edit</a>
                            <a href='delete_product.php?id=" . $row['id'] . "' class='button delete-button' onclick='return confirm(\"Are you sure you want to delete?\")'>Delete</a>
                            </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No products found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
        <a href="welcome.php" class="button">Back to Home</a>
    </div>
</body>
</html>
