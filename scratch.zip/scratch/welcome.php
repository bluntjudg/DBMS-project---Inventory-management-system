<?php
session_start(); // Start the session

// Redirect to login if the user is not logged in
if (!isset($_SESSION['user_name'])) {
    header("Location: index.php");
    exit();
}

// Fetch the logged-in user's name
$user_name = $_SESSION['user_name'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Inventory Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }
        .navbar {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            text-align: right;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            margin-left: 20px;
        }
        .container {
            padding: 20px;
            text-align: center;
        }
        .welcome {
            font-size: 24px;
            margin-bottom: 30px;
            color: #333;
        }
        .dashboard {
            display: flex;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap;
        }
        .card {
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            width: 200px;
            padding: 20px;
            text-align: center;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
        }
        .card h3 {
            font-size: 18px;
            margin: 10px 0;
            color: #4CAF50;
        }
        .card p {
            font-size: 14px;
            color: #666;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <div class="navbar">
        <span>Welcome, <?php echo htmlspecialchars($user_name); ?></span>
        <a href="logout.php">Logout</a>
    </div>

    <!-- Main Container -->
    <div class="container">
        <div class="welcome">
            Hello <strong><?php echo htmlspecialchars($user_name); ?></strong>, welcome to your Dashboard!
        </div>
        <div class="dashboard">
             <!-- Sales Card -->
    <div class="card" onclick="window.location.href='sales.php'">
        <h3>Sales</h3>
        <p>Record sales and update stock</p>
    </div>
            <!-- Products Card -->
            <div class="card" onclick="window.location.href='products.php'">
                <h3>Products</h3>
                <p>Manage your product list</p>
            </div>

            <!-- Suppliers Card -->
            <div class="card" onclick="window.location.href='suppliers.php'">
                <h3>Suppliers</h3>
                <p>Track your suppliers</p>
            </div>

            <!-- Inventory Card -->
            <div class="card" onclick="window.location.href='inventory.php'">
                <h3>Inventory</h3>
                <p>Check stock levels</p>
            </div>
        </div>
    </div>
</body>
</html>
