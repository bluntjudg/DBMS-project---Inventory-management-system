<?php
include 'db.php'; // Include database connection

// Check if a supplier ID is provided
if (!isset($_GET['id'])) {
    echo "No supplier ID provided!";
    exit();
}

$supplierId = $_GET['id'];

// Fetch the supplier details
$sql = "SELECT * FROM suppliers WHERE id = '$supplierId'";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    echo "Supplier not found!";
    exit();
}

$supplier = $result->fetch_assoc();

// Handle update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    $updateSql = "UPDATE suppliers SET name = '$name', email = '$email', phone = '$phone' WHERE id = '$supplierId'";
    if ($conn->query($updateSql) === TRUE) {
        header("Location: suppliers.php"); // Redirect back to suppliers page
        exit();
    } else {
        echo "Error updating supplier: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Supplier</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 400px;
            margin: auto;
            background: #fff;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            font-size: 14px;
            color: #555;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }
        .btn {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
        }
        .btn:hover {
            background-color: #45a049;
        }
        .back-btn {
            margin-top: 10px;
            text-align: center;
        }
        .back-btn a {
            color: #4CAF50;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Edit Supplier</h1>
        <form method="POST" action="">
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($supplier['name']); ?>" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($supplier['email']); ?>" required>
            </div>
            <div class="form-group">
                <label for="phone">Phone:</label>
                <input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($supplier['phone']); ?>" required>
            </div>
            <button type="submit" class="btn">Update Supplier</button>
        </form>
        <div class="back-btn">
            <a href="suppliers.php">Back to Suppliers</a>
        </div>
    </div>
</body>
</html>
