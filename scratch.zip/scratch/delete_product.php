<?php
// Include the database connection
include 'db.php'; // Make sure this path is correct

// Check if product ID is set in the URL
if (isset($_GET['id'])) {
    $productId = $_GET['id']; // Get product ID from URL

    // First, delete the related inventory record
    $deleteInventorySql = "DELETE FROM inventory WHERE product_id = '$productId'";
    if ($conn->query($deleteInventorySql) === TRUE) {
        // Now, delete the product from the products table
        $deleteProductSql = "DELETE FROM products WHERE id = '$productId'";
        if ($conn->query($deleteProductSql) === TRUE) {
            echo "Product and related inventory have been deleted successfully.";
        } else {
            echo "Error deleting product: " . $conn->error;
        }
    } else {
        echo "Error deleting inventory: " . $conn->error;
    }
} else {
    echo "Product ID is missing.";
}


?>

    <a href="products.php">
        <button>okayy</button>
    </a>