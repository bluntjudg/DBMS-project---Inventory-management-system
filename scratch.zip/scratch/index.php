<?php
// Start output buffering and session
ob_start();
session_start();

// Include the database connection
include 'db.php';

// Initialize variables for displaying messages
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['signup'])) {
        // Handle Sign-Up
        $name = $_POST['signupName'];
        $email = $_POST['signupEmail'];
        $password = password_hash($_POST['signupPassword'], PASSWORD_DEFAULT); // Hash the password

        // Insert user into the database
        $sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')";
        if ($conn->query($sql) === TRUE) {
            $message = "Sign-up successful! You can now log in.";
        } else {
            $message = "Error: " . $conn->error;
        }
    } elseif (isset($_POST['login'])) {
        // Handle Login
        $email = $_POST['loginEmail'];
        $password = $_POST['loginPassword'];

        // Retrieve user from the database
        $sql = "SELECT * FROM users WHERE email = '$email'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                // Set session variables and redirect to welcome page
                $_SESSION['user_name'] = $user['name'];
                header("Location: welcome.php");
                exit();
            } else {
                $message = "Incorrect password.";
            }
        } else {
            $message = "No user found with that email.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f4f4f9;
        }
        .container {
            width: 100%;
            max-width: 400px;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            text-align: center;
        }
        .container h1 {
            margin-bottom: 20px;
            color: #333;
        }
        .form-group {
            margin-bottom: 15px;
            text-align: left;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-size: 14px;
            color: #555;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }
        .btn {
            width: 100%;
            padding: 10px;
            border: none;
            background-color: #4CAF50;
            color: white;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #45a049;
        }
        .toggle {
            margin-top: 20px;
            font-size: 14px;
            color: #666;
        }
        .toggle a {
            color: #4CAF50;
            text-decoration: none;
        }
        .message {
            margin-top: 15px;
            font-size: 14px;
            color: #d9534f;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome</h1>
        <!-- Display Message -->
        <?php if (!empty($message)) echo "<p class='message'>$message</p>"; ?>

        <!-- Login Form -->
        <div id="loginForm">
            <h2>Login</h2>
            <form method="POST" action="">
                <div class="form-group">
                    <label for="loginEmail">Email:</label>
                    <input type="email" id="loginEmail" name="loginEmail" placeholder="Enter your email" required>
                </div>
                <div class="form-group">
                    <label for="loginPassword">Password:</label>
                    <input type="password" id="loginPassword" name="loginPassword" placeholder="Enter your password" required>
                </div>
                <button type="submit" class="btn" name="login">Login</button>
            </form>
            <p class="toggle">Don't have an account? <a href="#" onclick="toggleForm()">Sign Up</a></p>
        </div>

        <!-- Sign-Up Form -->
        <div id="signupForm" style="display: none;">
            <h2>Sign Up</h2>
            <form method="POST" action="">
                <div class="form-group">
                    <label for="signupName">Full Name:</label>
                    <input type="text" id="signupName" name="signupName" placeholder="Enter your full name" required>
                </div>
                <div class="form-group">
                    <label for="signupEmail">Email:</label>
                    <input type="email" id="signupEmail" name="signupEmail" placeholder="Enter your email" required>
                </div>
                <div class="form-group">
                    <label for="signupPassword">Password:</label>
                    <input type="password" id="signupPassword" name="signupPassword" placeholder="Create a password" required>
                </div>
                <button type="submit" class="btn" name="signup">Sign Up</button>
            </form>
            <p class="toggle">Already have an account? <a href="#" onclick="toggleForm()">Login</a></p>
        </div>
    </div>

    <script>
        function toggleForm() {
            const loginForm = document.getElementById('loginForm');
            const signupForm = document.getElementById('signupForm');
            if (loginForm.style.display === 'none') {
                loginForm.style.display = 'block';
                signupForm.style.display = 'none';
            } else {
                loginForm.style.display = 'none';
                signupForm.style.display = 'block';
            }
        }
    </script>
</body>
</html>
<?php ob_end_flush(); // End output buffering ?>
