<?php
session_start();
include 'db.php'; // Include the database connection

// Redirect to login if the user is not logged in
if (!isset($_SESSION['user_name'])) {
    header("Location: index.php");
    exit();
}

// Handle form submission to add a new product to inventory
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['addProductToInventory'])) {
    $productName = $_POST['productName'];
    $productPrice = $_POST['productPrice'];
    $stockLevel = $_POST['stockLevel'];

    // Insert product into the products table
    $sql = "INSERT INTO products (name, price) VALUES ('$productName', '$productPrice')";
    if ($conn->query($sql) === TRUE) {
        // Get the last inserted product ID
        $productId = $conn->insert_id;

        // Insert stock level into the inventory table
        $inventorySql = "INSERT INTO inventory (product_id, stock_level) VALUES ('$productId', '$stockLevel')";
        if ($conn->query($inventorySql) === TRUE) {
            $message = "Product added to inventory successfully!";
        } else {
            $message = "Error adding stock level: " . $conn->error;
        }
    } else {
        $message = "Error adding product: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management - Add Product</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }

        .container {
            width: 80%;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
            max-width: 500px;
            margin: 0 auto;
        }

        label {
            font-weight: bold;
            color: #333;
        }

        input[type="text"], input[type="number"] {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }

        input[type="text"]:focus, input[type="number"]:focus {
            border-color: #4CAF50;
            outline: none;
        }

        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #45a049;
        }

        .message {
            text-align: center;
            margin-top: 20px;
            padding: 10px;
            background-color: #f8d7da;
            color: #721c24;
            border-radius: 4px;
            border: 1px solid #f5c6cb;
        }

        .back-button {
            text-align: center;
            margin-top: 30px;
        }

        .back-button a {
            text-decoration: none;
        }

        .back-button button {
            background-color: #007bff;
            padding: 10px 20px;
            border-radius: 4px;
            font-size: 16px;
        }

        .back-button button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Inventory Management - Add Product</h1>

        <!-- Display message if any -->
        <?php if (isset($message)) { echo "<div class='message'>$message</div>"; } ?>

        <!-- Add Product Form -->
        <form method="POST" action="">
            <label for="productName">Product Name:</label>
            <input type="text" id="productName" name="productName" required>

            <label for="productPrice">Product Price:</label>
            <input type="text" id="productPrice" name="productPrice" required>

            <label for="stockLevel">Stock Level:</label>
            <input type="number" id="stockLevel" name="stockLevel" required><br>

            <button type="submit" name="addProductToInventory">Add Product to Inventory</button>
        </form>

        <!-- Back Button to Dashboard -->
        <div class="back-button">
            <a href="welcome.php">
                <button>Back to Dashboard</button>
            </a>
        </div>
    </div>
</body>
</html>
