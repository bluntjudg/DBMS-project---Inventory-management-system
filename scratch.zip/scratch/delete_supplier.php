<?php
include 'db.php'; // Include database connection

if (!isset($_GET['id'])) {
    echo "No supplier ID provided!";
    exit();
}

$supplierId = $_GET['id'];

// Delete the supplier
$deleteSql = "DELETE FROM suppliers WHERE id = '$supplierId'";
if ($conn->query($deleteSql) === TRUE) {
    header("Location: suppliers.php"); // Redirect back to suppliers page
    exit();
} else {
    echo "Error deleting supplier: " . $conn->error;
}
?>
