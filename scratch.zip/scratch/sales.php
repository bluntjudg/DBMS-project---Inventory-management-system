<?php
include 'db.php'; // Include database connection

// Check if product_id and quantity are set
if (isset($_POST['product_id']) && isset($_POST['quantity'])) {
    $productId = $_POST['product_id'];
    $quantity = $_POST['quantity'];

    // Fetch current stock level from inventory table
    $productSql = "SELECT inventory.stock_level, products.name FROM inventory
                   JOIN products ON inventory.product_id = products.id 
                   WHERE products.id = '$productId'";
    $productResult = $conn->query($productSql);
    
    if ($productResult->num_rows > 0) {
        $product = $productResult->fetch_assoc();
        $currentStock = $product['stock_level'];

        // Check if there is enough stock
        if ($currentStock >= $quantity) {
            // Calculate the new stock level
            $newStock = $currentStock - $quantity;

            // Update the stock level in the inventory table
            $updateStockSql = "UPDATE inventory SET stock_level = '$newStock' WHERE product_id = '$productId'";

            if ($conn->query($updateStockSql) === TRUE) {
                // Insert the sale record into the sales table
                $insertSaleSql = "INSERT INTO sales (product_id, quantity) VALUES ('$productId', '$quantity')";
                if ($conn->query($insertSaleSql) === TRUE) {
                    echo "<script>alert('Sale recorded and stock updated!'); window.location.href = 'sales.php';</script>";
                } else {
                    echo "Error recording sale: " . $conn->error;
                }
            } else {
                echo "Error updating stock: " . $conn->error;
            }
        } else {
            echo "<script>alert('Not enough stock available for this purchase.');</script>";
        }
    } else {
        echo "Product not found!";
    }
}

// Fetch all products and their stock levels from the inventory table
$sql = "SELECT products.id, products.name, products.price, inventory.stock_level 
        FROM products
        JOIN inventory ON products.id = inventory.product_id";
$result = $conn->query($sql);

// Fetch sales records
$salesSql = "SELECT sales.sale_id, products.name AS product_name, sales.quantity, sales.sale_date 
             FROM sales 
             JOIN products ON sales.product_id = products.id 
             ORDER BY sales.sale_date DESC"; // Sort by sale date
$salesResult = $conn->query($salesSql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: #fff;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            text-align: left;
            padding: 10px;
            border: 1px solid #ddd;
        }
        th {
            background-color: #f4f4f9;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .btn {
            padding: 5px 10px;
            text-decoration: none;
            color: white;
            border-radius: 4px;
        }
        .btn-purchase {
            background-color: #4CAF50;
        }
        .btn-cancel {
            background-color: #f44336;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Sales</h1>
    <form action="sales.php" method="POST">
        <label for="product_id">Product</label>
        <select name="product_id" id="product_id" required>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['id'] . "'>" . $row['name'] . " - Price: " . $row['price'] . " - Stock: " . $row['stock_level'] . "</option>";
                }
            } else {
                echo "<option>No products available</option>";
            }
            ?>
        </select><br><br>

        <label for="quantity">Quantity:</label>
        <input type="number" name="quantity" id="quantity" min="1" required><br><br>

        <input type="submit" value="Record Sale" class="btn btn-purchase">
    </form>

    <a href="welcome.php" class="btn btn-cancel">Back to Dashboard</a>

    <h2>Sales List</h2>
    <table>
        <thead>
            <tr>
                <th>Sale ID</th>
                <th>Product Name</th>
                <th>Quantity Sold</th>
                <th>Sale Date</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($salesResult->num_rows > 0) {
                while ($sale = $salesResult->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $sale['sale_id'] . "</td>";
                    echo "<td>" . $sale['product_name'] . "</td>";
                    echo "<td>" . $sale['quantity'] . "</td>";
                    echo "<td>" . $sale['sale_date'] . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='4'>No sales recorded.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

</body>
</html>
